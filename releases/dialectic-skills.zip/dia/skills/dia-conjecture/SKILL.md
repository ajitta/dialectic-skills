---
name: dia-conjecture
description: Test a universal claim using counterexamples and user-directed repairs. Use only when the message starts with dia-conjecture, when the skill is invoked by name, or when dia-router selects it; a request that only sounds like this is not an invocation.
license: MIT
metadata:
  author: ajitta
  version: "2.5.0"
  lineage: "new in plugin 1.3.0 (docs/research/candidates/modern-dialectic.md)"
  source: "https://github.com/ajitta/dialectic-skills"
---

# Proofs and Refutations

This skill runs the method of Lakatos's *Proofs and Refutations* on a strictly universal claim C that the user holds: a conjecture, rule or generalization about what is the case (not a policy to adopt), of the form "every A is B" (all, always, never, no A is B). Label: ch. 1 sections 1-6 (of section 6 only the deeper-proof move) and Rules 1-4. Sources, lineage and the departures from Lakatos: [references/theory.md](references/theory.md); read it only when the user asks about the method or the sources.

## Hard rules

1. **One case per message, one question per message.** A message fits a phone screen without scrolling, so it has no tables or headers, though a short numbered list of lemmas or repair options is fine.
2. **Every case shows its check,** condition by condition, so the user can fault it: that it meets C's antecedent (it is an A under the reading in force, defined in Step 1); for a case against C (global only or both), that it violates the consequent (it is not B); and for a case against a lemma (local only or both), which lemma it violates and how; a case whose check you cannot write is not raised. A check that rests on arithmetic or on how the case behaves states every condition its result needs (for a person's weight: what they ate and spent before the change, not only the change), because a result that depends on an unstated condition does not show the case violates anything.
3. **Evidence classes.** Each case says what it rests on: logic or definition / supplied by the user / verified this session (a tool ran) / single source / unverified recall, and your own recall is never "verified"; if a search tool is available, you may check a fact a case rests on. A C′ forced by a case that rests only on unverified recall is **conditional** on that case.
4. **The user rules; you classify.** Never rule for the user on whether a case counts; you classify their ruling by Step 4.
5. **No silent redefinition.** An "I meant …" or a narrowed term is a change to C: state the old and the new wording and what the new one no longer covers. One kind of correction is not:
   - **A restoring correction:** a correction, or the part of one, that only brings wording of yours in the Step 1 restatement back to the words of C's source (wording you added, replaced or left out, judged by those words, or by their meaning when you translated them). It is not a change to C at any point in the dialogue, because that wording was yours: C as fixed (your Step 1 restatement with every restoring correction applied) takes the restored wording, the record lists the correction when it came after a case was raised, and Step 1 says what happens to cases already raised.
     - **Any part of a correction that adds a restriction the source's words do not contain:** that part is a change to C.
6. **Withdraw only for a named defect.** Withdraw a case, a label or a recommendation only when you can name its defect (a condition the case fails, a misread term, a wrong evidence class); insistence is not a defect.
7. **The user decides the repair.** Recommend one option, and never write C′ as adopted before the user picks. When the user asks for the corrected claim before any repair is picked ("so how should I put it?"), give first the candidate C′ that the current case or the most suspect lemma points to, labelled a candidate the user has not picked, then continue with the one question.
8. **Quote only real words.** Quotation marks mean the user (or the text) said exactly that, so drop them when you paraphrase.
9. **Stop means stop.** On a stop signal ("stop", "enough", "wrap up", or the same in the user's language), go to the record (Step 6) at once.
10. **Quote C in its original language.**

## Step 0: Is it a strictly universal claim?

Take only a claim about every member of a class that says what is the case; a rule about what to do ("never deploy on Fridays", "every refund must be approved within a day") is a policy even when worded with all, every or never, or asked as "does it hold in every case". When it is not such a claim, say in one line where it fits, and stop unless the user restates it as a claim about what is the case; do not restate it that way yourself:

- "generally", "usually", "most", or a claim the user would keep despite one exception: dia-warrant (one counterexample to a defeasible claim is a rebuttal condition, not a refutation);
- a plan, policy, decision or idea: dia-counterplan for the opposing case, dia-quaestio to poke holes or stress-test, dia-negative for where it fails its own standard;
- what a word means: dia-elenchus;
- whether a set of statements yields Q and not-Q: dia-reductio.

If it is unclear whether the user means "every" strictly, make that your one question.

**Whose claim.** Infer it: the user's own words make it theirs, and a pasted text, or "your answer" (or the same in any language), makes it that text's or your earlier answer's; say in your first line whose claim it is, so the user can correct you. For a text or your earlier answer, the user takes the claim up for this dialogue and still rules on the cases; for your earlier answer, also say that this is a self-examination, that you will not defend it, and that you are then arguing both sides.

## Step 1: Fix C, ask for the proof

Restate C as "every A is B" in the key words of C's source, saying what A covers and what B asserts, and if you had to paraphrase, say "in my words" (a flag, not a second question). In the same message ask one question: why they hold it, that is, their argument or proof, offering to reconstruct it as [A] lemmas if they have none. If the message that states C already gives a reason or proof, however short ("because it burns calories"), take it as the argument and do Step 2 in the same message instead of asking for it.

The reading of C you state here, changed by any restoring correction and by each definition change the user adopts (hard rule 5, or a wider reading under Step 4), is the reading in force. Hard rule 2 and Step 4 check each case against it as it stood when that case was raised, so an adopted change applies from the next case on, with two exceptions, and a third rule for narrowings:
- **A wider reading adopted for a concept-stretching case:** it also applies to that case, because the user widened the claim to take that case in.
- **A restoring correction, at whatever point it comes:** it also applies to the current round's case until a repair for it is adopted, because the misreading was yours, not a move by the user. If that case's check cannot be written under the corrected reading, withdraw it as resting on a misread term (hard rule 6); if it can, show the check again and ask once more whether it counts. Cases of earlier rounds keep their rulings, because the user ruled on them as they were offered.
  - **The same correction also adds a restriction:** the restoring part applies first, and the restricting part is ruled on by Step 4 against the corrected reading, without asking again.
- **A narrowing, against a raised case that meets the reading in force:** it never reaches back; the narrowing is monster-barring and the case keeps its ruling, because Lakatos's Rule 2 forbids dismissing a refutation as a monster.

## Step 2: Proof-analysis

Split the argument into numbered lemmas L1 … Ln, each a step the argument needs, labelled [T] for the words of C's source (the user, the pasted text or your earlier answer; quote them) or [A] for a step you supplied because the argument needs it (one-line reason). Keep it to about five lemmas, mark the one you suspect most, and ask one question: "Is this your argument? Correct any line." A lemma keeps its number for the rest of the dialogue and in the record.

- An [A] lemma counts only after the user accepts it. If you reconstructed the proof, say in that message that you are then arguing both sides: you wrote the proof you attack.
- A reply that neither corrects a line nor rejects the analysis ("go on", "I'm not sure", "hmm, really?", or the same in any language) lets you go on: say in one line that you test the lemmas as a working reading, which the user can still correct, and raise the first case (Step 3) in the same message. Such a reply accepts nothing, neither an [A] lemma nor a ruling on a case nor a C′: an [A] lemma is accepted only when the user says so or picks an option that states it, and a repair builds in no lemma the user has not accepted. In the record, a lemma tested this way is [A, provisional] until accepted.
- If the user gives no argument and declines a reconstruction, say that without a proof there is no lemma to repair, so a case that counts leaves only giving up C or a response Lakatos rejects, and continue only if the user wants that.
- **Prior criterion** (Popper's prior refutation criterion; an addition to Lakatos): if C is empirical, resting on observation (people, systems, markets, measurements), ask it with the first case: present that case as an observable situation, and make the message's one question whether observing it would count against C. Record the answer as the criterion later rulings are held to; agreeing to the criterion is not a ruling that this case counts, so ask that next, against the criterion. If the first case is local only (a lemma fails, C survives), it cannot show what refutes C: ask the criterion as a question of its own before the first case against C; for a mathematical or definitional C, the check of hard rule 2 is the criterion.

## Step 3: Raise one case

Lakatos's Rule 1: look for cases both against C (**global**) and against the suspect lemmas (**local**). Aim first at the lemma marked most suspect, and choose the case most likely to be valid: from the user's own material first, then logical or definitional cases, then facts. Lakatos's Rule 3, applied to every case: before you send a case, check whether it fails C, a listed lemma or both, and label it **global only**, **local only** or **both**, because Step 5's repairs differ by that label. End the message with the one question: does the case count against C (for a local-only case, against Lj)?

Layout, one case per message (here C is "every sorted list can be binary-searched in O(log n) time", and L1 is "you can jump to the middle item in one step"):

> Case 2 (both: against C and L1): a sorted singly linked list.
> - A sorted list? Yes: its items are in order.
> - Searched in O(log n) time? No: reaching the middle item walks n/2 links, so the search takes O(n) time, though it makes only O(log n) comparisons.
> - L1 fails too: there is no jump, only a walk.
>
> Rests on: definition. Does this case count against your claim?

## Step 4: Classify the ruling

- **Counts:** the user accepts the case; go to Step 5.
- **Invalid:** the user names a condition the case fails under the reading in force (a case whose check cannot be written under a restoring correction is withdrawn by Step 1, not classified here). Check it: if the fault holds because the case's check read a term more widely than the reading in force, the ruling is concept-stretching (below); if it holds otherwise, withdraw the case ("invalid: fails [condition]"); if it does not hold, show the check's line for that condition once more, after which a reply that narrows the term is monster-barring and one that keeps the reading in force leaves the case disputed.
- **Concept-stretching:** the case meets C only under a reading of a term wider than the reading in force, other than your own wording that a restoring correction replaced (Step 1), so it does not count unless the user adopts the wider reading (a change to C: state the old and the new reading); if they adopt it, show the case's check again under the new reading, ask once more whether it counts, and record that answer as its ruling.
- **Monster-barring:** the user excludes a case that meets the reading in force by narrowing a term ("that's not a real A", "by A I meant …"), and a restoring correction is not this (Step 1). Name the move and accept it only as a definition change: the new definition, the content lost, and that Lakatos's Rule 2 forbids it ("Do not allow a refutation to be dismissed as a monster"). The changed claim becomes C′.
- **Disputed:** a bare "no", or insistence, with no condition named. Ask once which condition fails; if none is named, record the case as disputed, neither withdrawn nor counted, and move on to the next case.
- **The dispute turns into what a key term means:** say so and offer dia-elenchus for that question; the case stays disputed.

## Step 5: Repair (one message)

Branch on the case's label (Lakatos's Rules 2-4):

- **Local only** (Lj fails, C survives the case): Lakatos's Rule 4. Replace Lj by a lemma the case does not refute and the proof can still use. C is unchanged, unless an earlier repair built Lj into C: then the replacement widens C to cover the case (a deeper proof), and the user picks it like any C′.
- **Global only** (C fails, no listed lemma fails): the proof hides a lemma, so name the hidden lemma the case refutes and add it to the proof-analysis as the next L-number, marked [A, hidden] (the user accepts it by picking this option); then, by Lakatos's Rule 2, C′ is C with that lemma built in as a condition ("every A that … is B").
- **Both** (C and Lj fail): lemma-incorporation, Lakatos's Rule 2: C′ is "every A that meets Lj is B".
- **Weaker lemma** (the "suitable lemma" of Lakatos's Rule 2), for a case that fails C (global only or both), if you can find one: a condition weaker than the one you would build in, still usable by the proof, that more of C's cases meet but the counting case fails (show that in one line). Never offer a condition the counting case meets, or one that only restates B ("every A that ends up B is B"), because that empties C and is not a repair.
- **Give up C** is an option whenever C itself fails (global only or both).
- Exception-barring (listing the case as an exception) and monster-adjustment (reinterpreting the case so that it fits) only if the user asks for them, labelled as responses Lakatos rejects.

Number the options, saying for each in one line what it keeps and what it no longer covers; recommend one in one line with its reason, then ask the user to pick.

## Step 6: Next round, ending, record

A round is one case raised and then ruled on or withdrawn, with its repair if it counted. When a round ends, after the user picks a repair other than giving up C for a case that counts or after Step 4 settles any other ruling or the round's case is withdrawn, restate the current C (C as fixed, changed by every repair and definition change the user has adopted, if any; Steps 3 to 5 call it C in the next round) and the changed lemmas in one line, and raise the next case in the same message. After the third round, and not after later rounds, that message restates C and offers to stop instead of raising a case; continue if the user asks. If the repairs have turned into a list of exceptions, say so.

End when the user stops, when they give up C, when they accept the offer to stop, or when you find no further case you can check, and say which; never call C proved. Then print the record as plain Markdown, not a code block. Its result is the first of these that applies:

- **given up** (the user gave up C);
- **stopped before testing** (no case was ruled on);
- **open** (a counting case has no repair picked, or a disputed case remains whose check, redone at the end against C as it stood when that case was raised with each later repair and restoring correction applied, or against a lemma the current proof still uses, not replaced and not built into C, still holds; a repair can take a disputed case out, because the current C no longer claims anything about it, but a definition change never can, because a narrowing that excluded it would dismiss a possible refutation in which the user named no defect, which Lakatos's Rule 2 forbids (Step 1), and the case stays in the record as disputed whether or not the result is open);
- **revised, holding against the cases tried** (C′ adopted);
- **holding against the cases tried** (C unchanged).

Record:

- **Result:** … · rounds: n
- **Claim, as stated:** whose claim it is (the user's, a text's, your earlier answer's), then the exact words of C's source in quotation marks in their original language, shortened with an ellipsis when long (hard rules 8 and 10)
- **Claim, as read:** C as fixed, unquoted when you worded it, naming what your restatement adds to or narrows in the source's words (such as what A was taken to cover), or "same as stated" only when C as fixed is the source's exact words → C′, one arrow per change, each with its wording, unquoted when you worded it, and its reason (lemma-incorporation, hidden lemma built in, weaker lemma, deeper proof, exception-barring, monster-adjustment, definition change); a lemma replacement that leaves C unchanged goes under Proof-analysis
- **Proof-analysis:** L1 [T] "…"; L2 [A, accepted] …; L4 [A, provisional] …; L3 [A, hidden, added after case k] …; replaced: …
- **Prior criterion:** the user's answer (Popper's; an addition) | not asked (C is not empirical)
- **Cases:** one line each: kind (global only / local only, Lj / both, Lj), evidence class, ruling (counts / invalid / concept-stretching / monster-barring / disputed / withdrawn: the defect, for a case withdrawn under hard rule 6 other than by an Invalid ruling in Step 4, including one withdrawn under Step 1), response
- **Definition changes:** old → new; content lost; and each restoring correction made after a case was raised, as restored: your wording → the source's wording (after case k) | none
- **Conditional on:** cases resting only on unverified recall | none
- **Tried:** the lemmas and the kinds of case tried; the most suspect lemma now; "C′ not yet tested" if no case was raised against the last repair
- **Decision history:** one line per repair picked

A holding result must fill **Tried**: a claim nobody pressed has not held. If a filesystem exists and the user asks, save the record where they say.

## Pitfalls

- **Exception lists:** repairs that exclude cases one by one instead of naming the lemma that explains them. Look for the hidden lemma, or a weaker lemma.
- **Unnamed monster-barring:** yours or the user's. Reinterpreting a case so that it fits is monster-adjustment, offered only on request.
