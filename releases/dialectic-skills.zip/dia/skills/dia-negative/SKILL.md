---
name: dia-negative
description: Critique a claim or practice against its own stated standard. Use only when the message starts with dia-negative, when the skill is invoked by name, or when dia-router selects it; a request that only sounds like this is not an invocation.
license: MIT
metadata:
  author: ajitta
  version: "2.4.0"
  lineage: "negative-dialectics (installed copy, unversioned)"
  source: "https://github.com/ajitta/dialectic-skills"
---

# Negative Dialectics

No concept captures its object without a remainder; this skill shows a remainder only through a strict gap (Rules 2 and 5).

This skill is a practical adaptation of Adorno's method, not his own procedure: it runs internal critique, narrower than immanent critique, so its standard is only what the target itself states and it does not reconstruct norms a practice implies without stating them. Theory, sources and the limits of the adaptation are in [references/theory.md](references/theory.md); read it when the user asks about the method or when you are unsure whether a finding is strict or whether a standard is the target's own.

The output layout is in [references/output-template.md](references/output-template.md); read it before writing the first output, and if you cannot open it, follow the order of Steps 1–8.

## Parameters

`--target=user|claude|text|all` sets what is examined, and a natural-language equivalent of the flag counts as the flag; with neither, infer the target, which is `text` for a pasted text, `claude` for "your answer" or "what you said" (or the same in any language) and `user` otherwise, and state the inferred target in the first line so the user can correct it.

- **user:** a claim, concept, plan or self-description the user states.
- **claude:** your own earlier answer in this conversation (the most recent one unless the user names another; the value is `claude` on every assistant): quote it, examine it with the same strictness, and say in one line that this is a self-examination and not independent; neither defend the answer nor concede a gap that fails Rule 2.
- **text:** a pasted or attached text by someone else (a policy, mission statement, essay, argument): quote with location.
- **all:** run the procedure separately for each target present, in the order user, claude, text, skip absent targets with one line, then give one combined record.

## Hard rules

1. **The target's own standard only.** Judge the target only by its own claims, definitions, promises or stated goals, quote where it commits to each standard you use, and never bring in an outside value the target does not hold ("this is unfair" when it never claimed fairness).
2. **Strict gaps only.** A finding counts only when it has three parts: (a) the claim C in the target's own terms; (b) a particular case or consequence D; (c) a demonstration that, by C's own terms, D and C cannot both hold as stated. Vague tension, "it's reductive", "it feels incomplete", or an outcome that is merely undesirable are not findings.
3. **One reading at a time.** Fix the reading of C before testing it: when C has several live readings, test the one the target most plausibly means, or test each separately under its own label. Ambiguity alone is not a finding, so report it in one line and count a finding only where the gap is strict *within* a single reading; likewise, when a finding's argument splits into cases, it counts only for the branches where the gap is strict, and the other branches go into the conditional findings.
4. **Where cases come from.** Take D from the target's own material first, then from logical or definitional cases, then from facts, and label every fact with its evidence class (verified this session / supplied by the user / single source / unverified recall), where your own recall is never "verified". A finding is **conditional** when it rests on a fact that is single source or unverified recall, on one contested reading, or on one branch of a case split; a fact supplied by the user does not make a finding conditional, but is labelled "supplied by the user". List the firm findings (those that are not conditional) first, then the conditional ones under their own label.
5. **Determinate, not abstract, negation.** Each finding states exactly which part of C fails and what specific content C fails to capture; "It's more complex than that" negates nothing in particular and is not allowed.
6. **Purpose is an inference with evidence.** When you say what function or purpose an identification serves, ground it in the pattern of what C includes and excludes, label it as an inference, name the observation that would falsify it, and speak about what the claim or text does, not about anyone's hidden motives.
7. **No forced synthesis.** Do not end with a new master definition that claims to settle everything; a revised claim may be offered as an option, and it must state its own remainder: what it still does not capture.
8. **The user decides.** Recommend one option and do not decide for the user.
9. **Quote the target in its original language.** Use plain words, with Adorno's terms in parentheses at most.
10. **Whole analysis in one response.** Do not ask questions one at a time, because the skill runs in one pass.

## Procedure

### Step 1: Fix the target and the identifying claim

State C, the place where something is identified as something, and quote it; typical forms are "X is Y", "this policy is fair", "we are a merit-based company", "the goal is G", "this measures Z". If there are several such places, pick the one the rest lean on and list the others in one line as not examined.

### Step 2: State its own standard

List what C commits to, C1 … Cn, each with a quote: what it promises, what it says it measures or includes, what it says it is for. A purpose the target states is the **stated purpose**.

### Step 3: Gather particulars

Collect the cases C claims to cover, and check each against C1 … Cn.

### Step 4: Findings (determinate negations)

For each strict gap, write:

- **Claims:** Ck, quoted
- **Delivers:** what happens in case D
- **Why both can't hold:** the short argument, by C's own terms
- **Evidence:** source and class
- **What escapes:** the specific content C leaves out (the nonidentical remainder)

If no strict gap appears, say that C holds against the particulars tested, list them, and say where a gap would most likely show up if there is one; do not invent findings.

### Step 5: Function and purpose

Say what the identification does, its **operative function**: what it makes visible, what it hides, and what process it serves, or whose interests the pattern favors (as a function, not an intention); contrast it with the stated purpose from Step 2. Give as evidence the inclusion and exclusion pattern from Step 4, mark the result as an inference, and name as its falsifier (Rule 6) an observation the user could actually make (a document, a practice, a case) that would show the stated purpose (or, with none stated, another cause you name) explains the pattern as well, which a restatement of the stated purpose never is. If the findings do not support any reading beyond the stated purpose, say so.

Optionally, set C beside two or three concepts it depends on (for example "merit" depends on "measurement") when that shows where the gap comes from, and skip it when it explains nothing.

### Step 6: Options

Offer only the responses below that fit, each with what it keeps and what remainder it leaves; if no strict gap was found, the options are keeping C as it is or examining the most likely gap next, and you invent no others.

- narrow C to the scope where it holds (state C′ exactly; if the gap comes from how the practice works rather than from how C is worded, say that narrowing moves the gap rather than closing it)
- keep C and state the remainder openly
- change the practice so that what is delivered meets what is claimed
- withdraw C, or replace the stated purpose with the operative function and own it
- keep the tension open and examine a particular case further

### Step 7: Recommend

Pick one option and give: the reason; the evidence class of the weakest finding it rests on (with no strict finding: "no strict finding; rests on the tested particulars"), saying so when every finding it rests on is conditional; the observation that would change the recommendation. End with a sentence that the decision is the user's.

### Step 8: Record

Close with the record from references/output-template.md, or, if that file cannot be read, with this record: target and C; stated purpose; findings (n firm, m conditional); remainder; operative function; options and recommendation; decision; status; history. Its status is exactly one of: **open** (gaps found; by design nothing is closed) or **holding against the tested particulars**.

## When another agent fixes the output format

When the request comes from another agent or a script that fixes the output format (a schema or a set of fields) and no user will reply, carry out every step as usual and fit the result into that format as below, because such a caller may pass on only its list of items.

1. Give each strict gap (Step 4) as one of the caller's items, with its proof in the item's evidence field: Ck quoted, case D, why both can't hold, the evidence class, and firm or conditional (Rule 4).
2. End the list with one item labelled as this method's result, not a finding, that holds the Step 8 record, with C, the options and the recommendation; when no strict gap appears, this item says that C holds against the particulars tested and lists them.
3. In a severity or fix field, write that this method does not give it; the options and the recommendation are in the method result. If a field takes only fixed values, use the one that claims least, and say at the start of the item's text that the format forced that value and that this method does not give it.
4. Give nothing outside this method unless the caller names it in its request, and put what it names in a separate list after these items, labelled as outside this method; if the format has a free-text field, put the whole output there as well, in the template's layout.

## Follow-up turns

- **The user picks an option:** apply it, then examine the new claim the same way, since a revision is a new identification and has its own remainder, and add the decision to the record's history.
- **The user disputes a finding:** recheck it against Rules 2–4, taking the user's clarified reading of C as the target's own terms for target user and testing a proposed reading under Rule 3 for claude and text. Withdraw it only if you can name what fails (C misquoted or misread, D not a real case, the argument does not show that both cannot hold, or a wrong evidence class), because disagreement alone is not a defect; if you withdraw it, recheck each other finding on its own and say which stand; if the disputed finding holds, give the reason in one line and keep it.
- **The user says a standard is not theirs:** remove every finding that used it and rerun.
- **The user asks about the method:** answer briefly from references/theory.md.

## Pitfalls

- Abstract negation (Rule 5): "everything is socially constructed", "nothing captures reality".
- Jargon (Rule 9): Adorno's vocabulary standing in for an argument.
- Dismissal by default: if C holds against the particulars, say so (Step 4).
- Filling the template: an empty section is a result, not a gap to fill.
