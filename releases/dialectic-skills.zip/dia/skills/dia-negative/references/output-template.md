# Output template (dia-negative)

Translate every heading and label into the language of the user's latest message. Keep the target's quotes in their original language. Use plain words, numbered items and short lines so it reads on a phone. Adorno's terms may appear in parentheses after the plain label, never instead of it.

---

**Target:** user | claude | text | all (inferred from … — correct me if wrong)

## Claim
C: one sentence. Quote: "…"
Reading tested: … (if C is ambiguous: "C can also be read as …; that reading is tested separately / not tested". Ambiguity alone is not a finding.)
Not examined: (other claims, one line, if any)

## Its own standard
- C1 … — "quote"
- C2 … — "quote"
- Stated purpose: … — "quote" (or: none stated)

## Findings
1. Claims: C1 "…"
   Delivers: in case D, …
   Why both can't hold: …
   Evidence: … (target's own text | logical case | fact: verified / single source / unverified recall)
   What escapes: …
2. …

### Conditional findings
(Rest on an unverified fact, one contested reading, or one branch of a case split. Same five lines, plus "Conditional on: …".)

(If none: "C holds against these particulars: …. A gap, if any, would most likely show up in ….")

## Function and purpose
Stated purpose: …
Operative function (inference): …
Evidence: findings 1 and 2 show …
Would be falsified by: …
(Optional) Depends on: concept A, concept B — where the gap comes from.

## Options
- A. Narrow C to C′ = "…" — keeps …; remainder: …
- B. Keep C and state the remainder — keeps …; remainder: …
- C. Change the practice — …
- D. Withdraw C / own the operative purpose — …
- E. Keep the tension open; examine case … further

## Recommendation
Option X, because …
Rests on: finding n (evidence class).
Would change if: …
The decision is yours.

## Record
- Target / claim C:
- Stated purpose:
- Findings: n firm, m conditional — one line each (claims vs delivers)
- Remainder (what C does not capture):
- Operative function (inference, evidence class):
- Options: A–E offered — recommended: X
- Decision: pending | the user chose …
- Status: open | holding against the tested particulars | stopped
- History: (one line per follow-up turn)
