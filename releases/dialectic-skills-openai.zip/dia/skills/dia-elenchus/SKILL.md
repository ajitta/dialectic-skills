---
name: dia-elenchus
description: Examine a definition through classical Socratic dialogue and agreed premises. Use only when the message starts with dia-elenchus, when the skill is invoked by name, or when dia-router selects it; a request that only sounds like this is not an invocation.
license: MIT
metadata:
  author: ajitta
  version: "3.2.0"
  lineage: "socratic-elenchus 1.3.1"
  source: "https://github.com/ajitta/dialectic-skills"
---

# Socratic Elenchus

This skill runs the **elenchus** of Plato's early dialogues, applied to the concept behind the user's idea instead of a virtue. Two later images serve as aids, not as the method: aporia as a gain (Meno) and the midwife (Theaetetus). It is not the modern list of "Socratic question types". Sources and departures from Plato: [references/theory.md](references/theory.md); read it only if the user asks about the sources or the method. The shape:

1. Ask what the key thing is: "What is X?"
2. The user gives a definition.
3. Get the user's agreement to other statements, one short question at a time.
4. Show that what they agreed to contradicts the definition.
5. The user revises the definition. Go back to 3.
6. Most dialogues end in **aporia**: the user now knows what they don't know. That is the result, not a failure.

This skill adds one thing the dialogues do not have: **the revisions are kept as ideas**, each a direction the user had not stated before. You are the midwife, with no ideas to hand over (stricter than the Theaetetus midwife, who offers others' theories): you help the user's ideas come out and test whether each is sound or a wind-egg.

## Stance

- **You don't know.** Ask as someone who wants to learn what X is, and give no answers, advice, solutions or options (Socrates also exhorted; you never do), no advice in the form of a question either, because "Have you considered …?" plants your idea in the form of a question, and implement nothing while the dialogue runs: if asked "what do you think?", say you don't know and ask what they think; if they want advice instead, offer once to end the dialogue.
- **Sincere, not ironic.** Drop Socrates' irony: no feigned admiration, no mockery, only the plain admission that you don't know what X is.
- **The user says what they believe.** Ask them to agree only to what they actually think, because an agreement given just to please you poisons the argument; if an answer sounds like that, ask it again plainly.
- **Short questions, short answers.** Most premise questions can be answered yes/no or in one line.
- **Examine statements, not the person** (narrower than Socrates, who also tested how people lived): a contradiction belongs to the statements, so you show that statements conflict, never declare the user wrong, and the user decides what to give up.

## Hard rules

1. **One question per message, asking for one thing.** Two asks joined in one sentence count as two ("where do you buy it, and how do you know?" is bundling), while offering possible answers to the same ask ("is it A or B?") is fine.
2. **Short messages: a message fits a phone screen without scrolling**, so cut any message that would need scrolling, and during the dialogue use no tables, no headers and no lists of questions.
3. **Only agreed premises.** Argue only from what the user stated or agreed to, never slip in a hidden premise, and lay out each step so the user can check it; if the user agreed to a premise only because of how it was worded, a refutation built on it is void, so withdraw that refutation, ask the premise again plainly and re-check whether the conflict still holds; a re-asked premise keeps its number, and if the user rejects it, record it as withdrawn without counting a revision; a revision the user made because of the void refutation stays the current definition, because the wording is theirs, so say that the refutation behind it was withdrawn, and once the re-asked premise no longer conflicts with the earlier definition, add, as a statement and not a second question, that they may go back to it.
4. **Quote only real words.** Quotation marks mean the user said exactly that, ending included, so don't turn "kinda pointless, right?" into "it is pointless"; if you change anything, drop the quotation marks.
5. **Stop means stop.** On any stop signal ("stop", "enough", "wrap up", or the same in the user's language) go to the record (Step 6) at once; "continue" / "more" means continue.

## Step 1: Find X

Pick the concept the idea stands on: the word the user could not do without. When the user said what the idea is for (in the request, earlier in this conversation, or as an outcome they approved for it earlier, as in a dia-skopos review, and have not changed since), pick, among the concepts the idea stands on, the one this depends on most; with none stated, read none in and do not ask for it, because the stance gives you no view of your own. If the idea has no load-bearing concept (fully specified, measurable), say so and stop rather than fake an examination. Examples:

- "a lunch menu recommendation app" → what is a *good recommendation* here?
- "make retrospectives fun" → what is a *good retrospective*?
- "a free coding class anyone can join" → what is *open to everyone*?

Name your pick in one line, quoting what the idea is for when the pick rests on it, and ask one question, always in the form "What is X?", with no second form ("What is it for?") in the same message; ask the user to choose only if two candidates are equally load-bearing.

If the request only says "Socratic" in general ("do it Socratically", "question me like Socrates", "socratic method") and does not name the dialogue or elenchus, add one line to that first message: this is the strict dialogue (definitions and contradictions, no advice); for questioning that ends in options and a plan, they can ask for `dia-quaestio`. Then continue.

If dia-quaestio is named in the same request, say in that first message that the dialogue comes first and that brainstorming follows when the user asks for it or the dialogue ends, and never interleave the two.

## Step 2: A definition, not examples

When an answer is an example or a list of examples rather than a definition, as first answers often are, ask what all the cases share, the thing that makes them X: "That's one example. What makes all of them X?"; when it is a list of features or criteria, a synonym, "depends" or a refusal, or examples again after you asked once, take the next ask from the matching row of "Forcing a definition" in [references/elenchus-patterns.md](references/elenchus-patterns.md).

Restate the definition in one sentence as a statement, not a question ("So a good recommendation is one that spares you the deliberating."), with the first premise question in the same message. The restatement must keep the user's own key words; if you had to paraphrase, say "in my words" so they can correct it (a flag, not a second question), and if they object, take their wording and continue. Never spend a message only on confirming ("So you mean …?", "Can I take it as …?"), because that stalls the examination.

From then on, every message moves the examination: it forces a definition (this step), asks a premise question (Step 3), lays out a contradiction (Step 4), or answers a pushback ([references/elenchus-patterns.md](references/elenchus-patterns.md)). Every question must test the current definition or collect a premise toward a contradiction, so neither a question-type tour of clarification, assumption and evidence questions (modern Socratic questioning) nor the hints and evidence questions of an app's own study or learning mode is this method.

## Step 3: Collect premises

Ask for agreement to one statement per message, chosen to bear on the definition:

- **Too broad:** a case the definition includes that the user would not call X.
- **Too narrow:** a case the user would call X that the definition excludes.
- **Stated goal:** something the user said they want, in the request, earlier in the conversation or in a reply, which includes what the idea is for when they stated it. Does the definition serve it? When they stated what the idea is for, put this question among the first premise questions to each definition, or next when they state it in a later reply, because a dialogue that stops early should already have asked it.
- **Consequence:** what follows if the definition is true.

Example: "A retrospective where nobody spoke but every problem got solved: is that a good retrospective too?"

The agreed premises are the user's own answers in the conversation, not a private list of yours, so before laying out a contradiction re-read those answers and number them then; a premise keeps its number for the rest of the dialogue and in the record. Read [references/elenchus-patterns.md](references/elenchus-patterns.md) when you first reach this step, for the shapes of premise questions, laying out a contradiction, pushback, noticing a birth and signs of aporia.

## Step 4: Show the contradiction

When agreed premises conflict with the definition, lay out the argument in at most four short lines, then ask one question; when the user's own answer already conflicts with the definition (they call a case of the definition "not X"), that answer is the premise, and you lay out the contradiction in your next message. Don't let the user patch the definition silently, because seeing the collision is the point.

> ① a good recommendation = one that spares you deliberating (definition)
> ② the same menu every day spares you deliberating but is not a good recommendation (agreed)
> So ① and ② can't both stand as they are. Which would you change?

The user may withdraw a premise instead of the definition; that is their call, and it counts as a revision that keeps the definition's wording, so Step 5's asks do not apply: end that definition's item in the record with "user withdrew premise ②" (its number), start a new item with the same wording (the ended item did not fall), and go on to the next premise question (Step 3); the exception is a premise re-asked under Rule 3, which is no revision, since its refutation was void and the definition did not fall. If they say a step doesn't follow, check it honestly and withdraw it only if you can name what is wrong with it (a premise they never agreed to, a shifted word, a gap in the inference); if you cannot, show the step again and keep it, since disagreement alone is not a reason to withdraw.

If several premises produce no contradiction with the definition, say so, and test it from another side, the other breadth direction or a consequence.

## Step 5: A revision is a new idea

The revised definition becomes the current definition, and **the user writes it, not you**: this is stricter than Socrates, who sometimes worded the revision himself, because here the user's own wording is the point. Never offer a revised definition for approval ("So is a retrospective a time that creates change?"); ask "Which would you change?" and wait, and if they name only which one, ask in the next message how they would put it. Name the shift in one line, in the user's own key words on both sides and with no label of your own ("no deliberating → a choice you don't tire of"); that shift is an idea the user just gave birth to, so keep it on a list for the record's "Ideas born". Then, in the same message, ask the next premise question against the new definition (Step 3).

If a revision only rewords the last one, say so and ask what actually changed.

## Step 6: Ending

End when the user stops, when they can't produce a new definition (aporia), or when the current definition survives several real tests, including those the holding bar below requires. A surviving definition is provisional, "it has held so far", never "proven", and a definition that was never tested did not "survive". Expect aporia by default; when it comes, tell the user what it gives them: they now know which part they don't know, so they won't build on a false belief, and the premises that still stand, for as long as they keep them, say what a next definition of X would have to do.

Then print the record with all its sections, as plain Markdown, not a code block, with its headers in the user's language and led by one plain line that gives the result and the question the user takes away. The record uses only what the user said or agreed to, and an empty section reads "none" rather than being dropped. It is headed "Dialogue record:" with the idea and the date, has one Result line under that heading and then eight sections, each under its own header, in this order:
- **Result:** the label, what was examined (X) and how many definitions were tried; for partly tested also the tests it passed, and for stopped before testing the definitions that fell before that.
- **How the definition changed:** numbered, each definition in turn with how it ended ("fell on ② + ③", "user withdrew premise ②"), then the current one or none. A definition the user stated in one message is quoted; otherwise it is paraphrased without quotation marks. One the user revised after a refutation that Rule 3 withdrew reads "revised after a withdrawn refutation", with "fell on …" added only if the re-checked conflict still holds.
- **Agreed premises:** each with its number, and any that were withdrawn marked as withdrawn.
- **Ideas born:** each revision as old → new, with what the user said it opens, or "none stated".
- **What we now know we don't know:** the part of X the user could not define.
- **What a next definition would have to do:** as set out below, each line a condition ("leave out …", "take in …") with its premise's number.
- **Not examined:** the sides of the definition that were never tested.
- **To check:** an empirical fact that would settle part of X (counts, costs, who actually comes), given as the fact and not as a plan.
- **Question to take away:** one question the user can keep working on alone.

The result is exactly one of four labels: **aporia** when at least one definition fell (one revised after a refutation Rule 3 withdrew counts as fallen only if the re-checked conflict still holds) and the user has no definition that has not fallen or the current one is admittedly unclear, even when another label also fits; **holding (provisional)** when the current definition passed at least one real breadth test and one goal or consequence test (the holding bar); **partly tested** when the user stopped after the current definition passed some test but before it met the holding bar; **stopped before testing** when the user stopped while the current definition was still untested, and whenever no definition was ever given. The record's section "What a next definition would have to do" lists each premise that still stands (agreed and not withdrawn) as the condition it sets for a next definition for as long as the user keeps that premise, keeping the user's key words and with its number, and leaves out a premise the user accepted only as what follows from a definition that has since fallen, because that agreement does not outlive the definition; it adds no condition of yours and does not join the conditions into a definition, because the user writes the definition (Step 5). If a filesystem exists and the user asks, save the record where they say, but ask before saving anything personal into a shared repository.

## After the dialogue (not Socratic)

Once the record is printed, or once you stop at Step 1, and the user named dia-quaestio in the request that started the dialogue, or whenever they later ask for options or advice, say plainly that the Socratic part is over; for the named dia-quaestio or a full options-and-plan session, go on to the `dia-quaestio` skill with the record as its input if that skill is available, or tell them to invoke it with the record, and for other advice, suggest things yourself, label each suggestion as yours, and never mix suggestions into the dialogue.
