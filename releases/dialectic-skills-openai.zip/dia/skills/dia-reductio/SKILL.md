---
name: dia-reductio
description: Test a thesis by deriving a strict contradiction from stated premises. Use only when the message starts with dia-reductio, when the skill is invoked by name, or when dia-router selects it; a request that only sounds like this is not an invocation.
license: MIT
metadata:
  author: ajitta
  version: "3.0.0"
  lineage: "reductio (installed copy, unversioned)"
  source: "https://github.com/ajitta/dialectic-skills"
---

# Reductio ad Absurdum

Assume the thesis, derive from it and the listed premises a statement and its negation, and show that the set cannot all be true, so that the user sees which of the target's commitments cannot stand together and what each way out costs what the thesis is for.

Theory, history and the reasons behind the rules are in `references/theory.md`: read it when the user asks about the method (then answer briefly), or when you are unsure whether a step is strict. The output layout is in `references/output-template.md`; read it before writing the first output if you can open it (Step 8 names the record fields in case you cannot, and either way the output uses numbered lines, not wide tables, so it reads on a phone).

## Parameters

`--target=user|claude|text|all` sets what is examined, and a natural-language equivalent of the flag counts as the flag. If no flag is given, infer the target (a pasted text means `text`; "your answer", "what you said" or the same in any language means `claude`; otherwise `user`) and state the inferred target in the first line of the output so the user can correct it.

- **user:** a claim, belief, plan or argument the user states.
- **claude:** your own earlier answer in this conversation (the most recent one unless the user names another; the value is `claude` on every assistant). Quote it and examine it with the same strictness, saying in one line that this is a self-examination and not independent. If the answer turns out inconsistent, say so directly instead of defending it.
- **text:** a pasted or attached text by someone else. Quote with location (paragraph or line), and attribute claims to the text, not to the author's motives.
- **all:** every one of the above that is present, each run through the procedure separately in the order user, claude, text, then the combined record (Step 8). Skip absent targets with one line.

## Hard rules

1. **Strict contradiction only.** The absurdity is a formal contradiction, a statement Q and its exact negation not-Q (the contradictory: "all X are Y" contradicts "some X is not Y", not "no X is Y"), both derived from the thesis plus the listed premises, because only a contradiction shows by logic alone that the set cannot all be true. Two weaker conflicts count only through a premise you list, and a contradiction reached that way depends on that premise and says so:
   - **A consequence that is only false, implausible, ridiculous or undesirable:** usable only once its negation is written into the premise list.
   - **Two lines that are only contraries** ("all X are Y" / "no X is Y"): they conflict only given that some X exists, which you list with its label ([T] if the target said it, [L] only if it is a theorem of mathematics, otherwise [A]).
2. **No hidden premises.** List every premise with one of three source labels, and mark every fact among them with its evidence class (verified this session (a tool ran) / supplied by the user / single source / unverified recall), your own recall never being "verified":
   - **[T]** stated by the target (quote it); a definition is [T] only when the target states it (quote it).
   - **[L]** a law of logic or mathematics.
   - **[A]** added by you: an implicit premise the target seems to rely on, a definition the target did not state, or a fact. Give it a one-line reason it is needed; a contradiction that needs an [A] premise depends on it and says so.
3. **Every step names its rule.** Each derivation line cites the lines it uses and the rule (modus ponens, modus tollens, universal instantiation, substitution of a listed definition, conjunction, simplification, arithmetic, and so on), and an empirical or causal claim is never a step: if the chain needs one, it goes into the premise list, because only a step a rule licenses keeps the chain strict.
4. **One sense per term.** Fix the meaning of each key term in the premise list; if the chain only works when a term shifts meaning, that is equivocation, which you report instead of claiming a contradiction.
5. **Charity first.** Test the strongest reasonable reading of the thesis, and if two readings are live, test the stronger one and name the other in one line, because refuting the weak reading refutes a strawman.
6. **Logic shows inconsistency, not which member is false.** Write "the thesis is false" (when proving, "the thesis follows") only when every other premise the contradiction depends on is [L], and otherwise present the choice (Steps 6 and 7).
7. **The user decides.** Recommend one option and stop there, without continuing as if the recommendation had been accepted.
8. **Quote the target in its original language.** Logic labels ([T], [L], [A]) may stay as they are.
9. **Whole chain in one response.** Lay out the complete argument at once instead of asking premise questions one at a time.

## Procedure

### Step 1: Fix the target and the thesis

State the target, then the thesis in two lines, because the user can correct a reading only when it is shown apart from the words it reads:

- **Thesis, as stated:** the target's words, quoted (with their location, for a text).
- **Thesis, as read:** T in one sentence, always, the reading you test (Rule 5), followed by what it adds to or narrows in the quoted words, or "same as stated"; when two readings are live, the other one in one line.
- **What T is for:** the job the target relies on T to do (the decision, rule or conclusion it supports): the target's own words for it where it gives them, quoted, or an outcome the user stated or approved earlier in this conversation; otherwise "not stated", with your own reading in one line, labelled as yours, when the input makes one plain. A stated purpose decides which premises the derivation tries first; your own reading only weighs the options; neither changes what counts as a contradiction.

If the input contains several claims, T is the one the rest depend on, and the others are listed in one line as not tested, except a reason the target gives for T or a statement of what T is for, which is a premise (Step 3). If the user supposes something known to be impossible only to see what follows from it, not to test it, call it *per impossibile* reasoning, claim no refutation, and give the result as **stopped**.

### Step 2: Choose the direction

- **Refute (when the user asks to refute T, or names no direction and does not ask whether T is true):** assume T and look for a contradiction; if one appears, T or one of the premises must go.
- **Prove (indirect proof; when the user asks you to prove T):** assume not-T and look for a contradiction; if one appears, T follows, unless a premise goes.
- **Both (default when the user asks whether T is true):** run both and read the pair:
  - only T leads to contradiction → T is untenable on these premises
  - only not-T leads to contradiction → T follows from these premises
  - both lead to contradiction → premise set inconsistent: the fault is in the premises, not T
  - neither does → no contradiction found either way, which shows neither that the premises are consistent nor that they cannot decide T, only that this search found nothing; name the premise that would decide it

Concluding T because not-T led to a contradiction is indirect proof, which intuitionistic logic does not accept in general (it does when T is itself a negation); say so when it matters, above all for claims that something exists (see the theory reference).

### Step 3: List the premises

Number the premises P1, P2, … with labels [T], [L], [A] (Rule 2), keeping the list to what the derivation uses. A key term's meaning that the derivation relies on is a premise too: [T] if the target stated it (quote it), otherwise [A]. The reason the target gives for T and a stated purpose of T are premises and stay listed even when the derivation does not use them, [T] when the target states them and otherwise [A]; for a rule or practice so is its stated aim or another stated rule, which its generalized application must contradict. Your own reading of what T is for is not a premise.

### Step 4: Derive

Derive in numbered lines (Rule 3). Try first a derivation through the premises that state the reason for T or its stated purpose, because a contradiction between T and its own reason tells the user more than one between T and a side remark; when none comes that way, say so in one line and derive from the other premises. Stop at the first contradiction unless one that depends on fewer [A] premises is also within reach, in which case report that one even if its chain is longer; otherwise keep the chain as short as the logic allows. Before stating the contradiction, reread each line with the content words replaced by letters and confirm its rule still applies, because a step that holds only through an unlisted meaning is not strict, and record how the derivation was checked: by rereading only, or by a tool that ran (name it).

### Step 5: State the contradiction

Name the two lines that contradict each other and the full set they depend on, marking each [A] member.

Then grade its **strength** in this skill's own scheme (not a standard classification) and put the grade in the record. Below, *the assumption* is T when refuting and not-T when proving.

- **internal:** the set is only the assumption plus [T] and [L] premises. When refuting, the target contradicts itself; when proving, the target's own premises entail T.
- **conditional:** the set includes [A] premises, but they do not settle the matter alone.
- **carried by added premises:** the [A] premises, with any [L] premises but without the assumption, already entail its negation (not-T when refuting, T when proving). Check this every time an [A] premise is in the set, and show that short derivation or write "not found"; if it holds, say plainly that the reductio only restates what you assumed, so the real question is whether those [A] premises are true, and make the options and the recommendation turn on them.

When the direction is both, state and grade each contradiction separately, and the record gives one line per direction. For **premise set inconsistent**, one derivation's premises entail T and the other's entail not-T, so the premises of both derivations together (apart from T and not-T) cannot all hold. The options are the premises of either derivation, not T; a premise both derivations use breaks both at once, so name it if there is one.

### Step 6: Lay out the options

Give one option per member of the set the contradiction depends on that could be given up, each with what giving it up means, what else has to go with it and what it costs what T is for; how the assumption appears among them depends on the direction:
- **Refuting:** T is one of the options. Add a repair option where one exists: a narrowed thesis T′ that blocks the step that produced the contradiction, stated exactly, and say whether it still does what T is for.
- **Proving:** giving up the assumption not-T means accepting T, so that option reads "accept T".
- **Both directions, when the result is premise set inconsistent:** neither T nor not-T is an option and no repair is added, whatever the two cases above say, because the fault is in the premises (see Step 5).

### Step 7: Recommend

Pick one option and give the reason, the evidence class of the weakest premise the recommendation rests on, and the observation that would change the recommendation; then say in one line what the result lets the user decide now and what it leaves open (an [A] premise unverified, a reading not settled), and end with a sentence that the decision is the user's.

### Step 8: Record

Close with the record from the output template, whose fields are Target / thesis / what T is for, Result, Contradiction depends on, Strength, Checked by, Options (with the recommended one), Decision and History; for `--target=all` give one combined record whose lines carry one entry per target, and whose History has one line per follow-up turn, naming its target. Its result is exactly one of: **untenable on these premises**, **follows from these premises**, **premise set inconsistent**, **no contradiction found**, **stopped**.

### When no contradiction appears

Say so plainly: list the directions and premise sets you tried, write "no contradiction found with these premises; this does not show they are consistent, or settle whether the thesis is true", and name the premise that would decide it.

## When another agent fixes the output format

When the request comes from another agent or a script that fixes the output format (a schema or a set of fields) and no user will reply, carry out every step as usual and fit the result into that format as below, because such a caller may pass on only its list of items.

1. Give the contradiction (Step 5) as one of the caller's items, with its proof in the item's evidence field: the premises with their labels, the numbered derivation with its rules, the two lines that contradict each other, and the strength.
2. End the list with one item labelled as this method's result, not a finding, that holds the Step 8 record, with the result, what the contradiction depends on, the strength and the options with the recommended one; when no contradiction appears, this item says so as the section above requires, with the directions and premise sets tried.
3. In a severity or fix field, write that this method does not give it; the options and the recommendation are in the method result. If a field takes only fixed values, use the one that claims least, and say at the start of the item's text that the format forced that value and that this method does not give it.
4. Give nothing outside this method unless the caller names it in its request, and put what it names in a separate list after these items, labelled as outside this method; if the format has a free-text field, put the whole output there as well, in the template's layout.

## Follow-up turns

- **The user picks an option:** apply it (give up or narrow a premise, give up T, accept T, or adopt T′), add the decision to the record's history, and rerun Steps 3 to 8 on the revised set unless the option was giving up T or accepting T, since then nothing is left to derive and the updated record closes the turn.
- **The user disputes a step:** check it and add the outcome to the record's history: if you can name its defect (a wrong rule, an unlisted premise, a shifted term), withdraw the step and say whether the contradiction survives another way; otherwise, since disagreement alone is not a defect, show the step and its rule again and keep it.
- **The user rejects an [A] premise:** remove it, rerun Steps 3 to 8 on the revised set, and add the rejection to the record's history.

## Pitfalls

- A chain of small steps over a vague term ("one more grain does not make a heap"): each step may be valid, and the tolerance premise is the usual weak point. List it as a premise and offer it as an option.
- Quoting words the target did not say, or tidying a quote. If you paraphrase, drop the quotation marks.
