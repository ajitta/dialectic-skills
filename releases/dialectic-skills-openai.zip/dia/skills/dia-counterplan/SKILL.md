---
name: dia-counterplan
description: Construct a counterplan from contrary assumptions using the same evidence. Use only when the message starts with dia-counterplan, when the skill is invoked by name, or when dia-router selects it; a request that only sounds like this is not an invocation.
license: MIT
metadata:
  author: ajitta
  version: "2.5.0"
  lineage: "new in plugin 1.3.0 (docs/research/candidates/argumentation.md)"
  source: "https://github.com/ajitta/dialectic-skills"
---

# Dialectical Inquiry: Plan and Counterplan

Dialectical inquiry after Mason, run by one assistant in one chat: the counterplan is yours, the synthesis is the user's. Take a plan, decision or recommendation; list the assumptions it rests on; keep those the decision turns on; give each a plausible contrary; write the counterplan those contraries support on the same data; set the two side by side; then ask which assumptions from each side the user now holds. That set is the result, and you give no verdict on which plan wins.

In Mason's field study the plan came from the company's planners. One assistant writes both sides here, so the format obliges a counter-case but cannot ensure it is as strong as the plan, and hearing both sides is not evidence that the plan was tested. Sources, the evidence on dialectical inquiry and devil's advocacy, and the limits of this adaptation are in [references/theory.md](references/theory.md); read it only when the user asks about the method or its sources, then answer briefly. The output layout is in [references/output-template.md](references/output-template.md); read it before the first output if you can open it (Step 8 names the record fields in case you cannot).

## Parameters

`--target=user|claude|text` sets whose plan is examined.

| value | what is examined |
|---|---|
| `user` | a plan, decision or recommendation the user states (the default) |
| `claude` | your own earlier recommendation in this conversation, only when the user asks for it; the value is `claude` on every assistant |
| `text` | a plan, proposal or recommendation in a pasted or attached text by someone else |

The flag, or its natural-language equivalent, sets the target; with neither, infer it: a pasted text means `text`, "your recommendation" or "what you suggested" (or the same in any language) means `claude`, and anything else means `user`, so you never infer `claude` unless the user points to your answer. State the target in the first line of the output so the user can correct it. If several plans are present, take the one the user is deciding on and list the others in one line as not examined; if no plan is given, ask for it in one line.

- **user:** the user's own statement of their plan counts as [T].
- **claude:** quote your earlier recommendation, and say in one line that this is a self-examination and not independent: the same assistant wrote the plan and the counterplan. Do not write a weak counterplan to protect the answer, or an inflated one to look self-critical; Rule 3 holds as for any plan.
- **text:** quote with location, and attribute assumptions to the text, not to the author's motives.

## When this skill does not fit

- The question is about one claim, even as a devil's advocate ("play devil's advocate: is X true?", "is X healthy?"), not a plan, decision or recommendation: answer it without this skill.
- The user wants to be questioned about the plan, one question at a time: say in one line that dia-quaestio does that, and stop.
- The user asks only what the plan rests on, or only for its weak points, with no request for the opposing plan: run Steps 1 to 3 with no record, naming the key assumptions only, not the plan's flaws (Rule 1), then offer the counterplan in one line.

## Hard rules

1. **Build the alternative; do not carp.** The counterplan follows from contrary assumptions and is not a list of the plan's flaws; it must be a course of action a competent advocate could adopt and defend.
2. **Contraries, chosen and labelled.** For each key assumption state a specific, plausible contrary, not its bare negation: for "demand grows 10% a year", write "demand stays flat (supposing, for example, that the two largest buyers merge)", not "demand does not grow 10%". The choice is yours, so mark each one "my choice"; a mechanism in a contrary is a supposition, never a reported fact.
3. **Symmetry.** Pair every key assumption with its contrary, and write the counterplan at the same level of detail as the plan, citing the same data: if the plan names steps, costs or dates, the counterplan names the same slots. Where a slot needs a fact neither side has (a price, a measured quantity), write "not supplied" in the slot, which counts as matching detail, and the fact itself goes under "not tested" (Rule 4). A step, date or condition the counterplan itself chooses is not a fact: name it in its slot, never as "not supplied".
4. **No new facts.** Both sides use the plan's data and what the user supplies; never invent figures, sources or quotes for either side, and put a fact a side would need but neither has under "not tested". Label every fact with its evidence class: verified this session (a tool ran) / supplied by the user / single source / unverified recall; your own recall is never "verified". If a search tool is available and the user asks you to check a datum, check it and update its class for both sides.
5. **No verdict.** Do not say, or imply by tone, ranking or adjectives, which plan is better. If the user asks which wins, during the inquiry or after it, say in one line that this skill gives no verdict because you wrote both sides and that the result is their set, and name the observation that would decide each open pair.
6. **A ruling is not a challenge.** When the user rejects a contrary, record the ruling, and neither argue for the contrary nor soften it; rewrite a contrary only on a named defect: it misstates the data, or it contradicts another contrary.
7. **Quote the plan in its original language.** The labels [T] and [A] may stay as they are.

## Procedure

The first message runs Steps 1 to 7 and ends with Step 7's question, unless it ends earlier: with Step 1's question (or, when no plan is given, the one-line request for one), with the Step 8 record when Step 3 finds no key assumption on a counterplan request, or after Step 3, with no record, on an assumptions-only request. When the first message asks for the whole result in one response without questions, or says that no answer will come (a one-response run), those earlier endings still apply; otherwise it runs Steps 1 to 6 and ends with the Step 8 record in place of Step 7's question: every pair open, the result **undetermined**, and Step 7's question as the record's last line. A one-response run is not a stop. Later messages show only what changed (a new Cn, the counterplan steps on it, the changed pair) and fit a phone screen; a rerun or the record may be longer, in numbered lines, not tables.

### Step 1: State the plan

If the user has options but no recommendation, ask in one line which one to treat as the plan, and stop. Otherwise state the plan and its recommendation in one or two sentences, with an exact quote (copy the target's words; never reword inside quotation marks), and list the data it cites as D1, D2, …, each with its evidence class.

### Step 2: List the assumptions

Number the assumptions the recommendation rests on: A1, A2, …. Label each **[T]** stated by the target (quote it) or **[A]** reconstructed by you, with a one-line reason the plan needs it; a line you had to reword or infer is [A], even if it restates what the target said. Cover the situation (demand, people, costs, timing), what others will do, and what counts as success. A datum the decision turns on that is only single source or unverified recall is also an assumption, so list it. Keep to what the recommendation uses, usually five to ten.

### Step 3: Keep the key assumptions

Ask of each assumption the question from SAST, "if the opposite of this assumption were true, would it change the decision?", and give the answer in one line per assumption. Keep those where it would, as K1, K2, … (at most five; if more pass, keep the five with the largest effect and list the rest in one line).

If none passes, say so, write no counterplan, and go to Step 8: the result is **no key assumption found**.

### Step 4: State the contraries

For each Kn write Cn, a specific, plausible contrary (Rule 2), marked "my choice". Then check, one line each:

- **coherent:** C1 … Cn can all hold together; if two conflict, replace one and say which;
- **same data:** no Cn contradicts a datum D; a contrary may read a datum differently, and says how.

### Step 5: Write the counterplan

Write the course of action that follows from C1 … Cn and the same data, under Rule 3, marking which Cn each part rests on. It must be a different course of action, not the plan with a part removed; waiting or doing nothing counts if that is what follows.

### Step 6: Set them side by side

For each pair, in numbered lines rather than a wide table:

- Kn (plan) … / Cn (counterplan) …
- Favours the plan if: an observation the user could make. Favours the counterplan if: …

Then each side's recommendation in one line, and one line saying that one assistant wrote both sides.

### Step 7: Ask for the user's synthesis

Ask one question: which assumption from each pair do they now hold? They may answer per pair with the plan's, the counterplan's, one in their own words, or "can't tell". The set they give is the result, because the user, not you, forms the new assumptions, so do not suggest an answer. A leaning ("I lean toward …") counts as held only if the user says so; otherwise record the pair as open and note the lean in one word.

### Step 8: Record

When the user has ruled on every pair, or stops, or a one-response run (Procedure) reaches this step, close with the record from the output template. If you cannot open the template, the record is: target and plan (with the self-examination line for `claude`); key assumptions, and how many were listed; each pair with the user's ruling; result; kept for the side set aside; written by; not tested; rewrites; history; and, in a one-response run, Step 7's question as the last line. The result is exactly one of:

- **plan side held:** the user holds the plan's assumption on every pair;
- **counterplan side held:** the counterplan's on every pair;
- **synthesis:** a mix, or assumptions in the user's own words, with no pair left open;
- **undetermined:** at least one pair left open; the question stands (named after *teyku*, "let it stand", borrowed loosely from the Talmud);
- **no key assumption found** (Step 3);
- **stopped:** the user stopped before ruling on any pair (a one-response run is not a stop). If they stop after ruling on some, the result is **undetermined** and the unruled pairs are open.

Unless the result is **no key assumption found**, the record always says:

- **Kept for the side set aside:** for each pair, the strongest argument for the assumption the user did not hold, in one line, so a later decision can return to it (borrowed from the Mishnah's kept minority opinion, theory.md §6). For an open pair, the strongest argument on each side and the observation that would decide it. For a pair answered in the user's own words, keep the strongest argument for whichever of Kn and Cn their wording departs from more.
- **Written by:** one assistant wrote both sides of this comparison.
- **Not tested:** at least whether the shared data are accurate, assumptions not listed, alternatives other than these two, and how either plan would play out; then the line "Hearing both sides is not evidence that the plan was tested."

For **no key assumption found**, the record says instead: Not tested: whether the shared data are accurate, assumptions not listed, and alternatives to the plan; no counterplan was written, which does not show the plan is sound.

If the user then asks for a plan built on their set, sketch it after the record and label it as yours; the set, not the sketch, is the result.

## When another agent fixes the output format

When the request comes from another agent or a script that fixes the output format (a schema or a set of fields) and no user will reply, carry out every step as usual and fit the result into that format as below, because such a caller may pass on only its list of items.

1. Give no item for the plan's flaws (Rule 1) and no severity or ranking (Rule 5): this method's result is not a list of defects. If the caller also asks for the plan's defects, say in the method result that this method gives none.
2. Give one item labelled as this method's result, not a finding, whose text is the whole output in the template's layout, not shortened: the plan, the key assumptions with their contraries, the counterplan, the pairs side by side, and the Step 8 record of a one-response run with every line it requires (each pair open, the result undetermined, Kept for the side set aside, Written by, Not tested, and Step 7's question as the last line). When Step 3 finds no key assumption, the item holds that result with its Not tested line; on a request for the assumptions only, it holds the key assumptions, with no record and no counterplan.
3. In its severity and fix fields, write that this method does not give them. If a field takes only fixed values, use the one that claims least, and say at the start of the item's text that the format forced that value and that this method gives no severity or ranking (Rule 5).
4. The method-result item holds the whole output even when the format also has a free-text field; never point from the item to another field, because the caller may not pass that field on.

## Follow-up turns

- **The user rules on pairs:** record each ruling, and if a pair gets none, ask about it once, then record it as open.
- **The user rejects a contrary:** that is a ruling on the pair (Rule 6); record it with their reason if they give one, and count the pair as the plan's assumption held unless they give their own wording or say they can't tell. If they name a defect (it misstates a datum, or it contradicts another contrary), check it: if it holds, rewrite that Cn, redo Steps 4 to 6 for what rests on it, note the defect under rewrites, and ask for their ruling on the rewritten pair, which replaces the ruling recorded for the old Cn, since they rejected only the old Cn; if not, show the datum or line in one sentence and keep the Cn.
- **The user says the counterplan is weaker:** check Rule 3 and fix a named asymmetry (less detail, a datum left out); "It's weak" alone names none.
- **The user disputes the plan's assumptions:** withdraw an assumption only if you can name its defect (a misquote, or the recommendation does not need it), since insistence is not a defect; if the recommendation still needs the assumption, show where in one line and keep it. For target `user`, their clarification of their own plan is [T] and replaces the [A] line it covers.
- **The user adds an assumption:** it goes through Steps 3 to 7, and you ask for their ruling on the new pair before the record; if it would make more than five key pairs, say which pair it displaces, or list it as passed but not paired.
- **The user changes the plan:** treat it as a new plan, rerun, and add it to the history.
- **Stop signal** ("stop", "enough", "wrap up", or the same in the user's language): go to the record with what you have.

## Pitfalls

- A strawman counterplan: shorter, vaguer, or missing the plan's data.
- The side-by-side treated as proof that the plan was tested.
